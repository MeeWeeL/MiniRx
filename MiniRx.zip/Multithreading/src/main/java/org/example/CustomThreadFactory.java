package org.example;

import java.util.concurrent.atomic.AtomicInteger;

public class CustomThreadFactory implements java.util.concurrent.ThreadFactory {
    private final String namePrefix;
    private final AtomicInteger threadNumber = new AtomicInteger(1);
    private final AtomicInteger busyWorkers = new AtomicInteger(0);

    public CustomThreadFactory(String poolName) {
        this.namePrefix = poolName + "-worker-";
    }

    @Override
    public Thread newThread(Runnable r) {
        Thread thread = new Thread(r, namePrefix + threadNumber.getAndIncrement());
        System.out.println("[ThreadFactory] Creating new thread: " + thread.getName());
        return thread;
    }

    public int getBusyWorkersCount() {
        return busyWorkers.get();
    }
}