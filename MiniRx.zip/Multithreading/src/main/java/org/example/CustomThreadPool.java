package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class CustomThreadPool implements CustomExecutor {
    private final int corePoolSize;
    private final int maxPoolSize;
    private final int queueSize;
    private final long keepAliveTime;
    private final TimeUnit timeUnit;
    private final int minSpareThreads;
    private final ThreadFactory threadFactory;
    private final RejectedExecutionHandler rejectedHandler;

    private final List<Worker> workers = new ArrayList<>();
    private final AtomicInteger currentPoolSize = new AtomicInteger(0);
    private final AtomicInteger nextWorkerIndex = new AtomicInteger(0);
    private volatile boolean isShutdown = false;

    public CustomThreadPool(
            int corePoolSize,
            int maxPoolSize,
            long keepAliveTime,
            TimeUnit timeUnit,
            int queueSize,
            int minSpareThreads,
            ThreadFactory threadFactory,
            RejectedExecutionHandler rejectedHandler
    ) {
        this.corePoolSize = corePoolSize;
        this.maxPoolSize = maxPoolSize;
        this.keepAliveTime = keepAliveTime;
        this.timeUnit = timeUnit;
        this.queueSize = queueSize;
        this.minSpareThreads = minSpareThreads;
        this.threadFactory = threadFactory;
        this.rejectedHandler = rejectedHandler;

        for (int i = 0; i < corePoolSize; i++) {
            addWorker();
        }
    }

    private Worker findLeastLoadedWorker() {
        Worker leastLoaded = null;
        int minTasks = Integer.MAX_VALUE;

        for (Worker worker : workers) {
            int tasks = worker.getQueueSize();
            if (tasks < minTasks && tasks < queueSize) {
                minTasks = tasks;
                leastLoaded = worker;
            }
        }

        return leastLoaded;
    }

    private synchronized void addWorker() {
        if (currentPoolSize.get() >= maxPoolSize) return;
        Worker worker = new Worker(this, queueSize, keepAliveTime, timeUnit);
        workers.add(worker);
        Thread thread = threadFactory.newThread(worker);
        worker.setThread(thread);
        thread.start();
        currentPoolSize.incrementAndGet();
    }

    synchronized void removeWorker(Worker worker) {
        workers.remove(worker);
        currentPoolSize.decrementAndGet();
    }

    @Override
    public void execute(Runnable command) {
        if (isShutdown) {
            rejectedHandler.rejectedExecution(command, this);
            return;
        }

        if (workers.isEmpty()) {
            if (currentPoolSize.get() < maxPoolSize) {
                addWorker();
                execute(command);
                return;
            } else {
                rejectedHandler.rejectedExecution(command, this);
                return;
            }
        }

        int index = nextWorkerIndex.getAndUpdate(i -> (i + 1) % workers.size());
        Worker worker = workers.get(index);

        if (!worker.addTask(command)) {
            if (currentPoolSize.get() < maxPoolSize) {
                addWorker();
                execute(command);
            } else {
                rejectedHandler.rejectedExecution(command, this);
            }
        } else {
            System.out.println("[Pool] Task accepted into queue #" + index + ": " + command);
        }
    }

    @Override
    public <T> Future<T> submit(Callable<T> callable) {
        FutureTask<T> future = new FutureTask<>(callable);
        execute(future);
        return future;
    }

    @Override
    public void shutdown() {
        isShutdown = true;
        workers.forEach(Worker::stop);
    }

    @Override
    public void shutdownNow() {
        isShutdown = true;
        workers.forEach(worker -> {
            worker.stop();
            Thread.currentThread().interrupt();
        });
    }

    public int getCurrentPoolSize() {
        return currentPoolSize.get();
    }

    public int getCorePoolSize() {
        return corePoolSize;
    }

    public int getMinSpareThreads() {
        return minSpareThreads;
    }
}