package org.example.core;

public interface Disposable {
    void dispose();
    boolean isDisposed();
}