package org.example.core;

public interface Scheduler {
    void execute(Runnable task);
}